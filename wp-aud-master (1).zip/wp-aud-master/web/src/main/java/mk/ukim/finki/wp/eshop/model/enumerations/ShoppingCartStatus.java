package mk.ukim.finki.wp.eshop.model.enumerations;

public enum ShoppingCartStatus {
    CREATED,
    CANCELED,
    FINISHED
}
