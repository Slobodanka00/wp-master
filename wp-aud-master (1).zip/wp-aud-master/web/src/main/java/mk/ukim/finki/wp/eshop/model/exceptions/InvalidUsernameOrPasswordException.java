package mk.ukim.finki.wp.eshop.model.exceptions;

public class InvalidUsernameOrPasswordException extends RuntimeException {
}
